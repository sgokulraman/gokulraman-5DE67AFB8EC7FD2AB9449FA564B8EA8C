
def linearSearchProduct(productList, targetProduct):
  indlices = []

  for index, product in enumerate(productList):
    if product == targetProduct:
      indlices.append(index)

  return indlices


#example usage:
products = ["shoes", "boot", "loafer", "shoes", "sandal", "shoes"] 
target = "shoes"
target2 = "apple"
result = linearSearchProduct(products, target)
print(result)